package mk.ukim.finki.wp2024.lab.service;

import mk.ukim.finki.wp2024.lab.model.User;
import org.springframework.stereotype.Service;

@Service
public interface AuthService {

    User login(String username, String password);

}

