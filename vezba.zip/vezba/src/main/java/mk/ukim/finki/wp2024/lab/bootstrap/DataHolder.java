package mk.ukim.finki.wp2024.lab.bootstrap;


import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp2024.lab.repository.jpa.UserRepository;
import java.util.ArrayList;
import java.util.List;

import mk.ukim.finki.wp2024.lab.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class DataHolder {
    public static List<User> users = new ArrayList<>();
    private final UserRepository userRepository;
    @Autowired
    public DataHolder(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

@PostConstruct
    public void init() {
    if (this.userRepository.count() == 0) {
        users.add(new User("elena.atanasoska", "ea", "Elena", "Atanasoska"));
        users.add(new User("darko.sasanski", "ds", "Darko", "Sas"));
        users.add(new User("ana.todorovska", "at", "Ana", "Todorovska"));
        users.add(new User("admin", "admin", "admin", "admin"));
        this.userRepository.saveAll(users);
    }
}

}
