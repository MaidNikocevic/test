package mk.ukim.finki.wp2024.lab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VezbaApplicationTests {

    @Test
    void contextLoads() {
    }

}
